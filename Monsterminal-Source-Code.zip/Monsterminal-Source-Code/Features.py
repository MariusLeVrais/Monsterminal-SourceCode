import time
import os
import random

def bull():
    print("          ***BULL V3***          ")
    print("Bull is a open source software which use for generate strong password\n")
    input1 = input("Start (Y/n) : ")
    if input1 == "Y":
        print("Script are loading...")
        time.sleep(3)
        os.system("cls")
        print("1.Low")
        print("2.Medium")
        print("3.High")
        choice = input("Enter the type of password : ")
        if choice == "1":
            password = random.randint(0, 1000)
            print("Your password is : ", password)
        if choice == "2":
            password2 = random.randint(0, 1000000)
            print("Your password is : ", password2)
        if choice == "3":
            password3 = random.randint(0, 10000000000)
            print("Your password is : ", password3)
        quit = input("\nDo you want return to the terminal (Y/n) : ")
        if quit == "Y":
            os.system("cls")
            os.system("python mTER.py")
        else:
            os.system("cls")
            bull()
    else:
        quit2 = input("\nDo you want return to the terminal (Y/n) : ")
        if quit2 == "Y":
            os.system("cls")
            os.system("python mTER.py")

def HSC():
    import requests
    from bs4 import BeautifulSoup
    os.system("cls")
    time.sleep(3)

    print("Welcome to HSC bot !\n")

    search = input("Enter the web site url : ")

    site = requests.get(search)

    html = BeautifulSoup(site.content, 'html.parser')

    print(html)