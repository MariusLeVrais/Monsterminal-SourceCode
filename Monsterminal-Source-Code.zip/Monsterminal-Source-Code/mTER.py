import os
import Features
import winsound

winsound.PlaySound("Windows 11 New Start-Up Sound + New OOBE Intro Video.wav", 1)
print("MonsTerminal v1.3 2024\nCopyright (C) MTER Corporation. All rights reserved.")
while True:
    #Classic
    inputter = input("Monsterminal > ")
    if inputter == "cd":
        input13 = input()
        os.chdir(input13)
    if inputter == "write":
        input1 = input("")
        print(input1)
    if inputter == "new folder":
        input2 = input("")
        os.mkdir(input2)
    if inputter == "ip show":
        import socket
        hostname = socket.gethostname()
        IPAddr = socket.gethostbyname(hostname)
        print("IP :" + IPAddr)
    if inputter == "name show":
        hostname = socket.gethostname()
        print("PC_Name :", hostname)
    if inputter == "read":
        test = input()
        file = open(test , "r")
        print(file.read())
        file.close
    if inputter == "remove folder":
        input4 = input()
        os.removedirs(input4)
    if inputter == "new file":
        input5 = input()
        file1 = open(input5, "a")
        file1.close
    if inputter == "edit":
        input6 = input()
        file3 = open(input6, "w")
        input7 = input()
        file3.write(input7)
        file3.close
    if inputter == "start":
        input8 = input()
        os.system(input8)
    if inputter == "color 0":
        os.system("color 0")
    if inputter == "color 1":
        os.system("color 1")
    if inputter == "color 2":
        os.system("color 2")
    if inputter == "color 3":
        os.system("color 3")
    if inputter == "color 4":
        os.system("color 4")
    if inputter == "color 5":
        os.system("color 5")
    if inputter == "color 6":
        os.system("color 6")
    if inputter == "clear":
        os.system("cls")
    if inputter == "shutdown":
        os.system("shutdown")
    if inputter == "new frame":
        import tkinter
        windows = tkinter.Tk()

        windows.mainloop()
    if inputter == "cd":
        input11 = input()
        os.system("cd"+ input11)
    if inputter == "list":
        os.system("dir")
    if inputter == "mr robot":
        while True:
            os.system("color 2")
            os.system("dir")
    #Features
    if inputter == "load":
        print("1.Python\n")
        print("2.Bull v3\n")
        print("3.HSC\n")
        print("4.Browser\n")
        input10 = input()
        if input10 == "1":
            os.system("python")
        if input10 == "2":
            Features.bull()
        if input10 == "3":
            Features.HSC()
        if input10 == "":
            print("\nThe number doesn't exist, please enter 1,2,3,4 or 5")
    if inputter == "help":
        print("write : Write a text in the terminal\nclear : remove the text in the terminal\nread : read a specified file\nnew folder : create a folder in the directory\nnew file : create a file in the directory\nedit : edit and change the text in a file\nlist : list the elements in the directory\nversion: write the version of MonsTerminal\nload : for load modules and features\nhelp : a documentation with all commands and their effects\nstart : start a specified executable\nip show : for see his ip adress\nname show : for see his pc name\nnew frame : for open a windows\ncolor : for change the color with color number\ncd : for change directory")